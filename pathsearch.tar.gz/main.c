#include "pathsearch.c"
#include <stdio.h>
#include <string.h>


int main()
{
	char  command[10];
	printf("Enter a command to search PATH for: ");
	scanf(" %s10", command);
	char * path = get_path(command);
	if(path != NULL)
	{
		printf("%s\n", path);
		free(path);
	}else
		printf("%s not in PATH directory list\n", command);
}
