#ifndef PATH_C
#define PATH_C
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "parser2.c"

/* This function returns a char * to a copy of the PATH env variable*/
char * get_PATH()
{
	char * path_cpy = getenv("PATH");
	char * PATH = NULL;
	PATH = (char *)realloc( PATH, (strlen(path_cpy) +1) * sizeof(char));
	strcpy(PATH, path_cpy);
	return PATH;
}

tokenlist* tokenize_path(char ** PATH)
{
	tokenlist * t_list = new_tokenlist();
	t_list = get_tokens(*PATH, ':');
	return t_list ;
}

/*int main()
{

	char * PATH = get_PATH());	
	printf("full PATH var: %s\ntokenized PATH:\n", PATH);
	
	tokenlist * t_list = tokenize_path(&PATH);
	char ** token = NULL;
	token = (t_list -> items);
	while(*token != NULL){
		printf("token: %s\n", *token);
		token++;
	}

	free_tokens(t_list);
	return 0;
}*/

tokenlist* get_PATH_tokens()
{
	char * PATH = get_PATH();
	tokenlist * t_list = tokenize_path(&PATH);
	free (PATH);
	return t_list;
}

#endif
